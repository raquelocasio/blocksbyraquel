=== Blocks By Raquel ===
Contributors: webcodedesigner
Requires at least: 6.0
Tested up to: 6.0.2
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Blocks By Raquel is a WordPress plugin for adding useful Gutenberg block patterns. This is my first Gutenberg block pattern plugin.

== Description ==
Blocks By Raquel is a WordPress plugin for adding useful Gutenberg block patterns. This is my first Gutenberg block pattern plugin.

To install this plugin in your WordPress site:
1) Download the zip file in this repository to your computer.
2) In your WordPress dashboard, go to Plugins > Add New
3) Click Upload Plugin
4) Click Choose File, and select the file you just downloaded to your computer.
5) Click Install Now
6) Click Activate Plugin

The blocks are available in the block editor by clicking on the Patterns tab and selecting "Blocks By Raquel" in the dropdown menu.

![image](https://user-images.githubusercontent.com/75491857/191310411-36f730d4-da42-4a1b-bd3b-139da0918f61.png)


Enjoy!